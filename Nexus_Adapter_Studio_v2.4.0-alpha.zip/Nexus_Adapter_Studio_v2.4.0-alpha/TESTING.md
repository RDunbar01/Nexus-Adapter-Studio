# Verification scope

## Frozen release identity

The exact standalone HTML filename, byte count and SHA-256 are recorded in `release.json`. The included final verification report identifies the same frozen source. `SHA256SUMS` covers the delivered file contents.

Final approved HTML: 310,061 bytes, SHA-256 `9ab2111411e4a5700e910ad2a2148dc8d6eca8af640893e90ebcc93044e249fa`. The independent final suite passed 71 of 71 contract/UI/import/checkpoint/tokenizer tests and all included native numerical suites. See `verification/qa/INDEPENDENT_RELEASE_RECEIPT.json`; its six JSON evidence receipts identify this same application hash.

For a quick offline integrity check, run `python3 verify_release.py` from the extracted archive root. Integrity checks detect changed bytes; they do not establish model quality or hardware compatibility.

## What the checks exercise

- Generic architecture, complete tensor and tokenizer contracts, including fail-closed rejection cases.
- Independent retained token-ID and serialized-chat reference fixtures.
- Custom JSONL corpus import, deterministic held-out family selection, answer masking and formatting-mode behavior.
- Model capability controls, load-time checks and malformed checkpoint/corpus handling.
- Transactional checkpoint restore, optimizer/session compatibility, injected failures and base-state preservation.
- Tiny synthetic Llama/Smol-style, Gemma3, Qwen2.5-VL text, Mistral/Ministral and GPT-oss graphs using actual application JavaScript and WGSL.
- Forward comparisons against independent references, adapter gradients/finite differences, packed-example isolation, loss reduction, frozen-base preservation and checkpoint round trips where identified in the individual receipts.
- GPT-oss output-head-only capability and the released UI's default 120B block.

The final aggregate receipt and its listed files provide the detailed results, counts, hashes and numerical errors. Standalone family receipts may additionally describe narrower module-level checks; their own source hashes and scope apply.

## Test environments

Contract/UI tests run in Node with jsdom and memory/synthetic test doubles. Numerical graph tests use a bounded native Python wgpu bridge to a **CPU SwiftShader Vulkan WebGPU adapter**. They execute application kernels but do not launch a browser or use the user's physical GPU.

The Source + QA archive is checked independently after packaging: its guarded Python assembly must reproduce the exact approved HTML bytes, and its portable contract/UI/checkpoint tests must pass against the packaged HTML. See `SOURCE_BUILD.md` for requirements and omitted reference assets.

## What these results do not establish

- Full production-checkpoint numerical parity or successful full-size training.
- Useful downstream task improvement, factual accuracy or corpus quality.
- Browser visual/interaction behavior or deployment in a particular browser build.
- Radeon or other physical-GPU throughput, memory fit, utilization or stability.
- FP16 behavior on user hardware. The software test adapter did not qualify this route.
- Vision, image/video/projector, tool or multimodal training.
- GPT-oss transformer/router/expert training, or usable 120B operation.

All model base weights remain frozen. The dense routes still expand quantized matrices to FP16/FP32, so a small GGUF file is not evidence that training fits in VRAM. The separate GPT-oss route uses packed streaming and only trains the output head.

A finite-logit smoke test after loading a user-selected file is an early error check. It is not full-checkpoint parity or a performance/quality benchmark.
