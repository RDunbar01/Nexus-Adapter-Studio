# Nexus Adapter Studio v2.4.0-alpha

Release date: 2026-10-09

## Bring-your-own-corpus release

- Removes the bundled Nexus training/development curriculum. No corpus is preselected or automatically loaded.
- Adds detailed custom-corpus help and separate opt-in chat/raw JSONL examples.
- Adds verified model-specific chat formatting and explicit raw-completion formatting, including prompt/answer boundary masking and stable corpus identity.
- Retains family-separated held-out evaluation and resumable training state.

## Multi-family training

- Replaces SmolLM2-only admission with explicit architecture, tensor and tokenizer contracts.
- Adds real transformer LoRA routes for admitted plain Llama/Smol profiles, Gemma3 text, exact Qwen2.5-VL-7B text, Mistral-7B-v0.3 base, Mistral-Small-3.2-24B-Instruct-2506 text and Ministral-3-14B-Reasoning-2512 text.
- Adds GPT-oss-20B output-head LoRA on a frozen packed-streamed MoE graph. Transformer, expert and router adaptation remain unavailable.
- Keeps GPT-oss-120B disabled in the released UI.
- Checks all declared graph features and consumed tensors; unknown or unsupported variants are rejected rather than silently approximated.

## Integrity and safety checks

- Binds checkpoints to complete model/tokenizer identities, architecture, adapter configuration and corpus/session state.
- Validates imported checkpoints before replacing active training state, with rollback on supported injected allocation/write failures.
- Checks file bounds, duplicate keys/tensors, unsupported quantization encodings, allocation limits and finite load-time logits.
- Uses source-hash-bound final verification receipts included in the archive.

## Important limitations

This remains an experimental alpha. Graph support is separate from hardware fit and full-model qualification.

- No full-size production model was trained to establish parity, quality or speed for this release.
- Numeric graph tests use tiny synthetic weights on CPU SwiftShader WebGPU. Browser and physical GPU/Radeon execution were not validated. FP16 on user hardware is unverified.
- Dense frozen matrices expand to FP16/FP32. This is not QLoRA; 14B/24B/27B dense routes exceed a 20 GiB GPU before training overhead. GPT-oss uses a separate head-only packed-streaming route with unmeasured speed.
- Text only. No image/video/projector training, tools, arbitrary chat-template execution or blanket model-family support.
- `.nxadapter` is a custom resumable training checkpoint, not PEFT/GGUF-LoRA or a merged model.
- No application license has been assigned, and nothing has been published to GitHub.

See `README.md`, `CORPUS_GUIDE.md`, `TESTING.md` and `LICENSE_INFO.md` for the precise scope.
