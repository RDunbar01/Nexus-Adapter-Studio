#!/usr/bin/env python3
"""Offline package integrity check; this is not a model-quality test."""
from pathlib import Path
import hashlib
from html.parser import HTMLParser
import json

ROOT = Path(__file__).resolve().parent


class StandaloneParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.external_scripts = []
        self.scripts = 0

    def handle_starttag(self, tag, attributes):
        if tag == "script":
            self.scripts += 1
            if dict(attributes).get("src"):
                self.external_scripts.append(dict(attributes)["src"])


def main():
    manifest = json.loads((ROOT / "release.json").read_text(encoding="utf-8"))
    app = manifest["application"]
    data = (ROOT / app["file"]).read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    if actual != app["sha256"] or len(data) != app["bytes"]:
        raise SystemExit("FAIL: application bytes do not match the frozen release")
    count = 0
    for line in (ROOT / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        target = (ROOT / name).resolve()
        if not target.is_relative_to(ROOT):
            raise SystemExit("FAIL: unsafe path in checksum list")
        if hashlib.sha256(target.read_bytes()).hexdigest() != expected:
            raise SystemExit(f"FAIL: checksum mismatch: {name}")
        count += 1
    parser = StandaloneParser()
    parser.feed(data.decode("utf-8"))
    if parser.external_scripts or parser.scripts == 0:
        raise SystemExit("FAIL: unexpected standalone script structure")
    print(f"PASS: {count} file checksums; standalone HTML SHA-256 {actual}")
    print("Scope: artifact integrity only; see TESTING.md for execution evidence and limits.")


if __name__ == "__main__":
    main()
