# License and provenance information

## Application license: not specified

No project-wide application license was supplied for this release preparation, and this package does not invent or grant one. It is not being labeled MIT, Apache-2.0, public domain or otherwise open-source licensed.

Before publishing a repository or release, the project owner should select an appropriate license only for code they have the right to license, preserve any applicable third-party notices and review the provenance of reused material. This notice is not a license, a complete license audit or legal advice.

## Code provenance

- The initial Adapter Studio HTML and NexusAI repository were supplied for this work.
- GGUF decoding, tokenizer/metadata handling, hashing and the frozen GPT-oss inference route reuse the supplied NexusAI implementations.
- The release adds architecture contracts, differentiable family graphs, corpus formatting/help, guarded integration and verification tests around that supplied code.
- The `provenance/` records include GPT-oss vendor hashes and the retained Gemma, Qwen and Mistral source URLs/hashes. They record evidence and retrieval limits, not bundled assets or license grants. Source-archive family README files describe the implementation and reference scope.
- Papers and specifications are referenced for algorithmic background. Linking or implementing a method does not transfer the paper's or reference implementation's license to this application.

## Models, tokenizers and training data

No pretrained model weights, full tokenizer assets or ready-to-train curriculum are included. Users supply their own compatible model and corpus and are responsible for their respective usage and redistribution conditions. Each model's terms remain separate from any future application license.

The two example JSONL files are original, illustrative schema examples. They are not loaded automatically and do not grant rights to unrelated datasets.

## Development-only dependencies

The source package records `jsdom` 26.1.0 as a development dependency for contract/UI tests. Its source and dependency tree are not bundled. If you install or redistribute development dependencies, preserve their own license files and notices. The standalone application does not depend on jsdom.

Native numerical tests used Node, Python wgpu and a software Vulkan/SwiftShader environment. Those external runtimes and their binaries are not shipped in the application or source archive. Their licenses and installation requirements remain separate.

## Reference links

- [LoRA paper](https://arxiv.org/abs/2106.09685)
- [GGUF specification](https://github.com/ggml-org/ggml/blob/master/docs/gguf.md)
- [llama.cpp vocabulary implementation](https://github.com/ggml-org/llama.cpp/blob/master/src/llama-vocab.cpp)
- [OpenAI GPT-oss reference model](https://github.com/openai/gpt-oss/blob/main/gpt_oss/torch/model.py)
- [Pinned Qwen2.5-VL-7B-Instruct configuration](https://huggingface.co/Qwen/Qwen2.5-VL-7B-Instruct/blob/cc594898137f460bfe9f0759e9844b3ce807cfb5/config.json)

These links identify sources; they are not a statement of blanket redistribution permission.
