# Make your own training corpus

Nexus Adapter Studio requires a corpus you provide. The application contains no bundled training or development curriculum and does not load training examples automatically.

The separate `EXAMPLE_CUSTOM_CORPUS.jsonl` file contains five illustrative chat-format records, one per prompt family. `EXAMPLE_RAW_COMPLETION.jsonl` illustrates raw completion instead. These are format references, not recommended training datasets. Replace their contents with your own representative examples. The app uses a sample only if you explicitly choose and import it.

## 1. Create a UTF-8 JSONL file

Use a text editor to create a file such as `my_corpus.jsonl`.

- Put one complete JSON object on each physical line.
- Do not surround the records with an array or separate them with commas.
- Do not insert blank lines between records.
- Escape quotes inside strings as `\"` and line breaks inside strings as `\n`.
- Include at least five independent prompt families. A family can contain several related prompts or paraphrases.

Select **Verified model text-chat template** or **Raw completion** before tokenizing. The selected mode applies to every record in the imported file. Changing modes clears prepared tokens and the current session cursor; re-tokenize before training. Unsupported or unknown chat templates require an explicit raw-completion choice.

## 2. Choose the matching record format

### Verified chat: prompt and answer

```json
{"prompt":"Your input question","answer":"Your desired response","family_id":"topic-01"}
```

An optional `context` string becomes system context:

```json
{"context":"Answer in one sentence.","prompt":"Your input question","answer":"Your desired response","family_id":"topic-02"}
```

### Verified chat: messages

```json
{"messages":[{"role":"system","content":"Your task instructions"},{"role":"user","content":"Your input question"},{"role":"assistant","content":"Your desired response"}],"family_id":"topic-03"}
```

Every `content` value must be a string. An optional `system` message may appear first, followed by strictly alternating `user` and `assistant` messages, ending in `assistant`. The final assistant answer must not be empty or whitespace-only. If both `messages` and `prompt`/`answer` are present, the importer uses `messages`. Chat mode permits these two record schemas in the same file.

The loaded model must provide a verified supported text-chat template. Tool calls, images, separate reasoning-content fields, and arbitrary role layouts are not accepted. A model-specific template can impose further restrictions, including how system context is handled. Do not assume arbitrary chat templates or model families are supported merely because the JSONL is valid.

### Raw completion: exact prompt and continuation

```json
{"prompt":"Question: Your input question\nAnswer: ","completion":"Your desired response","family_id":"topic-04"}
```

`answer` can replace `completion`; if both are present, a non-null `completion` takes precedence. Raw mode rejects `messages` and nonempty `context`. It adds no role labels, separators, system prompt, or extra newline. Include every desired delimiter in your `prompt` string. The model's required BOS, when configured, and EOS are handled by the tokenizer.

Raw mode tokenizes the exact concatenation of prompt and completion, then masks the common prompt-token prefix. If a token crosses the text boundary, that token becomes part of the supervised answer. An empty tokenized prefix is rejected; a suitable prompt delimiter can prevent the entire prompt from merging into the first answer token.

## 3. Group related prompts

Use the same `family_id` string for prompts that are paraphrases or belong to the same closely related task. This keeps the entire family on one side of the training/evaluation split.

For each record, the importer chooses its family in this order:

1. A nonempty `family_id`
2. A nonempty `split_component_id`
3. A hash of the preceding chat messages in chat mode, or the exact prompt string in raw-completion mode

Without explicit family IDs, identical preceding messages stay together, but differently worded paraphrases may become different families. Add family IDs when that distinction matters.

An optional `record_id` string is accepted for identifying records. Fields such as `split`, `category`, and `source_ids` do not control training or evaluation selection. In particular, `"split":"validation"` does not force a record into the held-out set.

## 4. Understand the automatic held-out split

The importer requires at least five distinct families. It sorts family identifiers, then reserves the first selected percentage of families for evaluation, rounded down with a minimum of one family. The setting is 5–30%; the default is 10%.

Examples:

- Five families at 10%: one held-out family and four training families
- Twenty families at 10%: two held-out families and eighteen training families

This is a deterministic sorted-family split, not a random split. It is a percentage of families, not records or tokens. The training shuffle seed does not change which families are held out. Both resulting sets must be nonempty. Exact token-sequence duplicates across the two sets are rejected.

## 5. What the model learns

In verified-chat mode, only the final assistant answer and the template's answer-ending tokens contribute to the loss and answer-token budget. System context, earlier conversation, and padding do not count as answer targets. In raw-completion mode, the supervised continuation and EOS are counted, including any token that straddles the prompt/completion boundary. Earlier tokens can still provide context within the selected window.

Long records use sliding context windows. Tokens outside a window are not attended to, although answer targets are scheduled across windows. A valid long record does not increase the engine's supported context limit.

## 6. Import and train

1. Open the HTML in a WebGPU-capable desktop browser, using localhost if needed.
2. Load a model accepted by the app's architecture, tensor, and tokenizer checks.
3. Choose verified-chat or raw-completion formatting, your matching `.jsonl` file, and the held-out-family percentage.
4. Click **Tokenize imported corpus** and check the training/held-out record counts.
5. Choose adapter targets and a short answer-token budget, then start a session.
6. Evaluate the adapter against the frozen base and inspect generated responses.
7. Export a `.nxadapter` checkpoint. Browser storage is not a durable backup.

For exact session resume, load the same base model, prepare the same corpus with the same formatting mode and holdout setting, import the checkpoint, then resume. Preserve record contents and order. Cross-device numerical differences may still occur.

## Import limits and common errors

- File-input imports must be smaller than 50,000,000 bytes; the parser also requires fewer than 50,000,000 JavaScript string code units.
- At most 100,000 JSONL records are accepted.
- A messages record must contain 2–100 messages. Each message's content is limited to 100,000 string code units.
- A raw-completion record's prompt and completion together are limited to 200,000 string code units.
- A tokenized record's prompt plus answer must fit the 100,000-token record limit. This is separate from the much shorter training context window.
- An internal blank line is invalid JSONL for this importer.
- Fewer than five independent families cannot produce an accepted automatic holdout.
- Changing `split` labels will not change held-out selection; use the supported family and percentage controls.
- A malformed import leaves the currently prepared corpus and resumable session in place.

Use examples you have permission to use. Keep evaluation families representative of the behavior you care about, and avoid duplicating records merely to make the file larger.
